import { NgModule } from '@angular/core';
import { LogWindowComponent } from './log-window.component';

@NgModule({
    declarations: [
        LogWindowComponent
    ],
})
export class LogWindowModule { }
