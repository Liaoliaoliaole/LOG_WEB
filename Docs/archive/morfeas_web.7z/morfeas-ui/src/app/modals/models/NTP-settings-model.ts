export interface NTPSettingsModel {
    NTP: string;
}
