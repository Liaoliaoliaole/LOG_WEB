export interface LogListModel {
    logPath: string;
    logList: string[];
}
