export interface HostnameModel {
    Hostname: string;
}
